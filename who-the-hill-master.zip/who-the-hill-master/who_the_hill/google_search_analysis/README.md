# Google Search Analysis

## Purpose

These scripts are separate from Shazongress' main features and were used to help generate a list of doppelgängers and nicknames for Congress members. These scripts were also used as a way to gauge how accurate the Amazon Rekognition API could identify Congress members, assuming the Google image results included the actual Congress members.